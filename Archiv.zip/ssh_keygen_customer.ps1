# SSH Key Generator für Windows
# Beschreibung: Dieses Skript erstellt ein SSH-Schlüsselpaar und speichert den öffentlichen Schlüssel auf dem Desktop.
# Es nimmt KEINE Löschungen oder Systemänderungen vor. 

# Pfade festlegen
$sshFolder = "$env:USERPROFILE\.ssh"  # Standard-Speicherort für SSH-Schlüssel
$privateKey = "$sshFolder\customer_key"  # Privater Schlüssel
$publicKey = "$sshFolder\customer_key.pub"  # Öffentlicher Schlüssel
$desktopPublicKey = "$env:USERPROFILE\Desktop\customer_key.pub"  # Ziel: Desktop

Write-Host "Starte SSH-Key-Generierung... Bitte einen Moment Geduld." -ForegroundColor Cyan

# Prüfen, ob das .ssh-Verzeichnis existiert, andernfalls erstellen
if (-not (Test-Path -Path $sshFolder)) {
    Write-Host "Erstelle das .ssh-Verzeichnis unter $sshFolder" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $sshFolder | Out-Null
}

# Prüfen, ob ein Schlüssel bereits existiert
if (Test-Path -Path $privateKey) {
    Write-Host "WARNUNG: Ein SSH-Schlüssel 'customer_key' existiert bereits!" -ForegroundColor Red
    Write-Host "Das Skript wird beendet, um bestehende Schlüssel nicht zu überschreiben." -ForegroundColor Red
    exit
}

# Generiere das SSH-Schlüsselpaar
ssh-keygen -t rsa -b 4096 -f $privateKey -N "" | Out-Null

# Überprüfen, ob die Schlüssel erfolgreich erstellt wurden
if ((Test-Path -Path $privateKey) -and (Test-Path -Path $publicKey)) {
    Write-Host "SSH-Schlüssel erfolgreich erstellt." -ForegroundColor Green

    # Kopiere den öffentlichen Schlüssel auf den Desktop
    Copy-Item -Path $publicKey -Destination $desktopPublicKey

    # Abschlussmeldung
    Write-Host "Der private Schlüssel wurde sicher gespeichert in: $privateKey" -ForegroundColor Green
    Write-Host "Der öffentliche Schlüssel wurde auf dem Desktop abgelegt als: 'customer_key.pub'" -ForegroundColor Green
    Write-Host "Bitte senden Sie die Datei 'customer_key.pub' vom Desktop per E-Mail." -ForegroundColor Cyan
} else {
    Write-Host "FEHLER: Die Erstellung der SSH-Schlüssel ist fehlgeschlagen!" -ForegroundColor Red
}